class ConstantStrings {
  static const String userIdLoggedIn = 'userIdLoggedIn';
  static const String ERBCONA = 'ERBCONA';
  static const String ERBTECH = 'ERBTECH';
  static const String HSE = 'HSE';
  static const String FUEL = 'FUEL';
  static const String ERBCustomerCheckListResponse =
      'ERBCustomerCheckListResponse';
  static const String avergaeClusterScore = 'avergaeClusterScore';
  static const String TopPerforming = 'TopPerforming';
  static const String BottomPerforming = 'BottomPerforming';
  static const String NcResponse = 'NcResponse';
  static const String userDetails = 'userDetails';
}
